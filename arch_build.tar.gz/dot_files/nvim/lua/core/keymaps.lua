vim.api.nvim_set_keymap('i', 'jj', '<Esc>', { noremap = true })

vim.api.nvim_set_keymap('n', '<F10>', ':w<CR>:!g++ -fsanitize=address  -Wall  -Wextra -Wconversion -Wsign-conversion -Wshadow -DONPC -pedantic -O2 -o %< % && ./%<<CR>', { noremap = true })
vim.api.nvim_set_keymap('i', '<F10>', ':w<CR>:!g++ -fsanitize=address  -Wall  -Wextra -Wconversion -Wsign-conversion -Wshadow -DONPC -pedantic -O2 -o %< % && ./%<<CR>', { noremap = true })

vim.api.nvim_set_keymap('n', '<F9>', ':w<CR>:!g++ -fsanitize=address  -Wall -Weffc++ -Wextra -Wconversion -Wshadow -DONPC -O2 -o %< % && ./%< < inputf.in<CR>', { noremap = true })
vim.api.nvim_set_keymap('i', '<F9>', ':w<CR>:!g++ -fsanitize=address  -Wall -Weffc++ -Wextra -Wconversion -Wshadow -DONPC -O2 -o "%<" "%" && "./%<" < inputf.in<CR>', { noremap = true })

vim.api.nvim_set_keymap('n', '<F8>', '<Esc>:w<CR>:!g++ -o %< % && ./%<<CR>', { noremap = true })
vim.api.nvim_set_keymap('i', '<F8>', '<Esc>:w<CR>:!g++ -o %< % && ./%<<CR>', { noremap = true })

vim.api.nvim_set_keymap('', '<Esc>', ':noh<CR>', { noremap = true })

vim.api.nvim_set_keymap('', '<Leader>a', 'ggVG', { noremap = true })

vim.api.nvim_set_keymap('', '<Leader>s', ':source ~/.config/nvim/init.lua<CR>', { noremap = true })
