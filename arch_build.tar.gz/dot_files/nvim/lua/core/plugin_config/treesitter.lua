require 'nvim-treesitter.configs'.setup {
  ensure_installed = { "c", "lua", "vim", "javascript", "typescript" },
  sync_install = false,
  auto_install = false,
  autotag = {
    enable = true,
    filetypes = {
      'html', 'javascript', 'typescript', 'javascriptreact', 'typescriptreact', 'svelte', 'vue', 'tsx', 'jsx', 'rescript',
      'css', 'lua', 'xml', 'php', 'markdown'
    },
  },
  highlight = {
    enable = true,
    disable = { "latex" },
  },
  indent = {
    enable = true,
  },
}
