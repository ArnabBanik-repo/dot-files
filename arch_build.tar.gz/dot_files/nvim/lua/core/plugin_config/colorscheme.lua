vim.o.termguicolors = true
vim.o.background = "dark"

vim.cmd [[ colorscheme gruvbox ]]
vim.cmd [[ hi LineNr guibg=none guifg=#999999 ]]
