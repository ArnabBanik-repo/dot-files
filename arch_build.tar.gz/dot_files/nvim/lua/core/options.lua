vim.g.mapleader = ' '
vim.g.maplocalleader = ' '

vim.opt.backspace = '2'
vim.opt.showcmd = true
vim.opt.laststatus = 2
vim.opt.autowrite = true
vim.opt.cursorline = true
vim.opt.autoread = true
vim.opt.cursorline = false

-- use spaces for tabs and whatnot
vim.opt.tabstop = 2
vim.opt.shiftwidth = 2
vim.opt.shiftround = true
vim.opt.expandtab = true

vim.cmd [[ set noswapfile ]]
vim.cmd [[ hi NvimTreeNormal guibg=NONE ]]

--Line numbers
vim.wo.number = true
vim.wo.relativenumber = true

-- Neovide configurations
if vim.g.neovide then
  vim.g.neovide_window_blurred = true
  vim.g.neovide_floating_blur_amount_x = 2.0
  vim.g.neovide_floating_blur_amount_y = 2.0
  vim.g.neovide_transparency = 1
  vim.g.neovide_cursor_antialiasing = true
  -- Helper function for transparency formatting
  local alpha = function()
    return string.format("%x", math.floor((255 * vim.g.transparency) or 0.8))
  end
  -- g:neovide_transparency should be 0 if you want to unify transparency of content and title bar.
  vim.g.neovide_transparency = 0.0
  vim.g.transparency = 0.8
  vim.o.guifont = "Hack Nerd Font:h9" -- text below applies for VimScript
  vim.g.neovide_background_color = "#0f1117" .. alpha()
end

vim.filetype.add({
  filename = { ['.env.local'] = 'sh', ['.env.example'] = 'sh', }
})
