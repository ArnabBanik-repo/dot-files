# Song Recommendations

## Live Albums
---
1. Pink Floyd – Pulse
2. John Mayer – Where the Light Is
3. Eric Clapton – Live at Budokan
4. B.B. King – Live at the Regal
5. King Crimson – USA
6. David Gilmour – Live at Pompeii
7. The Allman Brothers Band – At Fillmore East
8. Jimi Hendrix – Band of Gypsys
9. Stevie Ray Vaughan – Live Alive
10. Cream – Live at the Royal Albert Hall
