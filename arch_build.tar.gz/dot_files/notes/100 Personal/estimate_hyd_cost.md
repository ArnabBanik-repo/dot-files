# Estimated cost of living

1. PG - 12k
2. Groceries - 3k
3. Travel - 1k
