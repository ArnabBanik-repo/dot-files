# Module 6

## Random surfer model
- **Assumption**: Surfer randomly clicks on links without caring about the content.
- After a certain time, the probability that he will search for something completely different -> damping factor -> d.

## Page Rank Formula
- (1-d) + d * (PR(Ti)/C(Ti) + ...)
- d -> damping factor.
- Ti -> nodes with incoming edges to the current node.
- PR(Ti) -> Page rank of Ti.
- C(Ti) -> No. of outgoing edges from Ti.
