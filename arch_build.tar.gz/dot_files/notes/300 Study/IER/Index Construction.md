# Index Construction

## Blocked Sort Based Indexing
- Large corpus
- Apply single pass of the data
- Applicable when main memory is insufficient for entire data
- Term referred to with Term ID
- Time complexity -> O(T log T) (T -> number of termID - docID pairs)

### Process
- Segments the collection into parts of equal size
- Sort -> Term ID - Doc ID pairs of each part in memory
- Stores intermediate results on disk
- Merges all intermediate results into final index

## Single Pass In Memory Indexing
- Done when the data structure for mapping term -> termID wouldn't fit in the memory
- Scalable alternative to BSBI -> SPIMI
- Uses terms instead of term ID
- Can index collections of any size if there is disk space
- Time complexity -> O(T)

### Difference from BSBI
- SPIMI -> adds posting directly to its posting list without collecting all termID - docID pairs and sorting them
- Faster, since there is no sorting
- Saves memory since we do not use termID
- Efficient
- Can implement **compression** -> increases efficiency -> process larger blocks

### Process
- Allocate space for short posting list at first, then double when filled
- When memory -> exhausted -> write block to disk
- Before writing to disk -> sort the terms -> PL -> we want sorted
- Merge the blocks into final inverted index

## Distributed Indexing
- Very large collections -> single machine indexing impossible
- Eg. WWW
- Index construction -> several machines
- Two ways of implementation
  1. Partitioning by terms -> global index organization
  2. Partitioning by docs -> local index organization

**Global Index organization**
- Dict of index terms -> partitioned into subsets -> each subset at a node
- We also keep the postings for those terms
- Query -> routed to the nodes corresponding to its query terms
- Greater concurrency
- Non-trivial

**Local Index organization**
- Common
- Each query -> all nodes -> results merged before returning
- Trades more local disk seeks for less inter-node communication
- Difficulty: global stats (eg idf) req entire coll, but each node only has a subset of the docs
- Background processes -> refresh node indexes with global stats

## Map Reduce
- General architecture -> special implementation -> distributed architecture
- Designed for large computer clusters
- Robust -> in case of failure -> reassign
- Master - Worker
- Two phases: map (generates key value pairs), reduce (all values for a key collected into one list)

![Map Reduce Architecture](./map-reduce.png)

### Map Phase
- Map split -> input data to key-value pairs
- Phase parser machines
- O/P -> local intermediate files (segment files)

### Reduce Phase
- Values for given key -> stored closed together
- Partition the keys into j term partitions and have parsers writer key-value pairs for each term partition into a separate segment file

#### Inverter
- Collect all values (docIDs) for a given key into one list
- Master -> each term partition to different inverter
- List of values -> sorted for each key -> written to final sorted PL
