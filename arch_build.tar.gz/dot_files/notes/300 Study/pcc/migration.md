# Migration

---

## Hot Migration
- Migration of a VM from one physical device to another without any suspension of services
- This can be done when migration of servers is required without suspension of services
- Also done when there is a problem in the servers and migration is done before the problem can affect the applications.

## Steps
1. Pre-migration
    - VM running on host A
    - Block device mirroring and free resources
    - Host B may be pre-selected for migration

2. Reservation
    - Create container in host B

3. Iterative pre-copy
    - Enable shadow paging
    - Iteratively copy dirty pages

4. Stop and copy
    - Suspend functioning of host A 
    - Copy remaining VM state to host B 
    - Configure ARP to redirect traffic to host B

5. Commitment
    - VM on host A released.

6. Migration complete
    - Start VM on host B
    - Resume operations
    - Normal connections to local devices re-established
