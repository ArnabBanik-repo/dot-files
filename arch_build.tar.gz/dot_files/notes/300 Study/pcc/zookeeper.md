# Zookeeper 

---

## Zookeeper Guarantees
- Atomicity - A transaction is either completed or failed
- Update persistence - An update persists unless overwritten by the client
- Update sequence - Updates are strictly applied in the order in which they were received
- Reliability - System will function if most of the server functions are up
- Single server image for all clients - Same system image irrespective of the serverthe client connects to
