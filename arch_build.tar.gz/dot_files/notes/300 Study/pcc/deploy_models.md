# Cloud Deployment Models

---

## Public Cloud

### Advantages
- Cost effective
- No infrastructure management
- No maintainence
- Dynamic scalability
- No cost setup

### Disadvantages
- Low customization
- Security


## Private Cloud

### Advantages
- High security
- Better control
- High customizability
- Better support for legacy systems

### Disadvantages
- High cost
- Low scalability

## Hybrid Cloud

### Advantages
- High flexibility and control
- Better security
- Low cost

### Disadvantages
- Complex architecture
- High latency

## Community Cloud

### Advantages
- Shared resources
- Low cost
- Data sharing
- Better security

### Disadvantages
- Rigid for customization
- Low scalability

## Multi Cloud

### Advantages
- High availability
- Low latency

### Disadvantages
- Complex architecture (bottlenecks)
- Security issue
