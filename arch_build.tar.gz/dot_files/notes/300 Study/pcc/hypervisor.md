# Hypervisor

---

## Definition
- A piece of computer software that sits between the hardware and the virtual machines and allows the interaction of virtualized environments with the physical hardware. 
- Acts as an interface between the virtual machines and the system. 
- Allows running multiple virtual machines simultaneously
- Provides high security
- Allows multiple users to use the same hardware with different OS and applications without interfering in each others systems (isolation)

## Advantages
- High security
- High portability
- Easy to conceptualize
- Isolation
- Cheap

## Cons
- Single point of failure
- Buffer overflow

## Reasons for virtualization
- Resource sharing
- Isolation among users
- Dynamic resource allocation
- Optimized resource usage
- Efficient cpu utilization
- Cost efficient

## Type 1 Hypervisor
- Sits on top of the hardware
- Interacts directly with ISA
- Emulates the ISA layer for the virtual machines to interact with
- Called native virtual machine

## Type 2 Hypervisor
- Requires an operating system to run on
- Is like a normal software
- Emulates the ISA layer for VMs by using ABI system calls
- Called hosted virtual machine
