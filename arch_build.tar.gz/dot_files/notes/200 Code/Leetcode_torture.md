# LeetCode Torture

--- 

- Download the leetcode daily problem as an html file
- Open it up in a browser
- Open a text editor for the user to code in
- Ask him to manually submit it


- Find a way to download the webpage
- From the downloaded folder, delete everything except the .jpg images
`shopt -s extglob && rm !(*.jpg)`
- Modify the html file to keep only the <p> to the </ul> tag
