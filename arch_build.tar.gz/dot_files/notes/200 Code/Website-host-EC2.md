# Hosting a website on an EC2 instance

## Steps
1. Create EC2 Instance
2. Create bucket and put all HTML files in to the bucket
3. Run commands

## Create Instance
- Create instance and launch it.
- In security group add SSH, HTTP TCP protocol in port 80 and HTTPS 443 0.0.0.0/0
- Create new key pair and download it and launch 

## Creating bucket
- Create S3 storage service
- Create bucket
- Give unique name
- Select the bucket checkbox, edit public settings and untick all tickboxes
- Open the bucket and uplaod files
- Import zip file
- Select the object, go to actions and make the file public

## Commands
- sudo su
- yum update -y
- yum install gcc
- yum install httpd
- service httpd start
