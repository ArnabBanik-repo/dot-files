# Spring Boot notes
---

## Application properties (application.properties)

1. Logging
```logging.level.root=DEBUG```

2. Port
```server.port=5000```

3. Actuator Endpoints
```management.endpoints.web.exposure.include=*```


## API Filtering

1. Static
Done at model level.
```@JSONIgnore```, ```@JSONIgnoreProperties```

2. Dynamic
Have to do at controller level.

- At model level, add 
```java
@JsonFilter("<Filter_name>")
```

- At controller level, manually serialize the model objects and add the filters as shown.
```java
MappingJacksonValue value = new MappingJacksonValue(user);
SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("name");
FilterProvider filters = new SimpleFilterProvider().addFilter("Test_filter", filter);

value.setFilters(filters);
```
