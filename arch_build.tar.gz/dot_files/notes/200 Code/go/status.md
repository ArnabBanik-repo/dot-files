# Status

## Currently studying

### Learn Go with Tests

- [X] Install Go
- [X] Hello, World
- [X] Integers
- [X] Iteration
- [X] Arrays and Slices
- [X] Structs, methods & interfaces
- [ ] Pointers and errors
- [ ] Maps
- [ ] Dependency Injection
- [ ] Mocking
- [ ] Concurrency
- [ ] Select
- [ ] Reflection
- [ ] Sync
- [ ] Context
- [ ] Intro to property based tests
- [ ] Maths
- [ ] Reading files
- [ ] Templating
- [ ] Generics
- [ ] Revisiting arrays and slices with generics


## Todo
