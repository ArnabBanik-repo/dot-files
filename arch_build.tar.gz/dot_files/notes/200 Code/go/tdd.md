# Test Driven Development

## Steps

- Write a failing test and see it fail so we know we have written a relevant test for our requirements and seen that it produces an easy to understand description of the failure
- Writing the smallest amount of code to make it pass so we know we have working software
- Then refactor, backed with the safety of our tests to ensure we have well-crafted code that is easy to work with

## Test function requirements

- It needs to be in a file with a name like `xxx_test.go`
- The test function must start with the word `Test`
- The test function takes one argument only `t *testing.T`
- In order to use the `*testing.T` type, you need to import `"testing"`, like we did with fmt in the other file

## Example

```go
func TestHello(t *testing.T) {
	got := Hello("Chris")
	want := "Hello, Chris"

	if got != want {
		t.Errorf("got %q want %q", got, want)
	}
}
```

## Running multiple tests for the same code function

```go
func TestHello(t *testing.T) {
	t.Run("saying hello to people", func(t *testing.T) {
		got := Hello("Chris")
		want := "Hello, Chris"
		assertCorrectMessage(t, got, want)
	})

	t.Run("empty string defaults to 'world'", func(t *testing.T) {
		got := Hello("")
		want := "Hello, World"
		assertCorrectMessage(t, got, want)
	})

}
```

## Helper Functions

We would often want to use

```go
if got != want{
    t.Errorf("...")
}
```

So create a `test_helper` function that would contain this logic. Test helpers are not considered tests, and the compiler wouldn't run them while testing.

```go
func assertCorrectMessage(t testing.TB, got, want string) {
	t.Helper()
	if got != want {
		t.Errorf("got %q want %q", got, want)
	}
}
```

Notice the change from `t *testing.T` to `t testing.TB`. `testing.TB` is an interface that contains both `testing.T` and `testing.B`.

## Examples

Examples show up in the documentation. Examples are added in the `xxx_test.go` files.

```go
func ExampleAdd() {
	sum := Add(1, 5)
	fmt.Println(sum)
	// Output: 6
}
```

## Benchmarking

```go
func BenchmarkRepeat(b *testing.B) {
	for i := 0; i < b.N; i++ {
		Repeat("a")
	}
}
```

To run the benchmarks use `go test -bench=.`

## Coverage

`go test -cover` to see what percent of the areas of the code the tests are covering


