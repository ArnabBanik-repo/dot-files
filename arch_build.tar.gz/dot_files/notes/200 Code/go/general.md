# General Notes on Go

## Arrays and Slices

1. Arrays := fixed sized collection of numbers
```go
a := [3]int {1, 2, 3}
b := [...]int {1, 2, 3}
```

2. Slices := varying sized collection of numbers
```go
a := []int {1, 2, 3}
```

### Make function

Creates a slice with a fixed size. Size increases dynamically with need.

```go
sums := make([]int, 2)
a := sums[0]
b := sums[1]
c := sums[2] // runtime error
```

### Append 

To append to slice

```go
sums = append(slice, 50)
```

### Slice

```go
a := []int {1, 2, 3, 4}
b := a[1:3]
```

## Slicing Array Example

```go
func main() {
	x := [3]string{"Лайка", "Белка", "Стрелка"}

	y := x[:] // slice "y" points to the underlying array "x"

	z := make([]string, len(x))
	copy(z, x[:]) // slice "z" is a copy of the slice created from array "x"

	y[1] = "Belka" // the value at index 1 is now "Belka" for both "y" and "x"

	fmt.Printf("%T %v\n", x, x)
	fmt.Printf("%T %v\n", y, y)
	fmt.Printf("%T %v\n", z, z)
}
```

**Creating a copy of a slice of a large array is good**
```go
func main() {
	a := make([]int, 1e6)     // slice "a" with len = 1 million
	b := a[:2]                // even though "b" len = 2, it points to the same the underlying array "a" points to

	c := make([]int, len(b))  // create a copy of the slice so "a" can be garbage collected
	copy(c, b)
	fmt.Println(c)
}
```

## Maps

Maps feel like pass by reference. 
Maps are essentially pointers to runtime hmap structure.

So when you pass a map to a function/method, you are indeed copying it, but just the pointer part, not the underlying data structure that contains the data.
A gotcha with maps is that they can be a nil value. A nil map behaves like an empty map when reading, but attempts to write to a nil map will cause a runtime panic.

Therefore, never do

```go
var m map[string]string
```
Instead, do either

```go
var dictionary = map[string]string{}
```
or

```go
var dictionary = make(map[string]string)
```
